const fs = require('fs');
const path = require('path');
const { BrowserWindow } = require('electron');
const { copySync } = require('fs-extra');
const notificationpath = path.join('C:/ProgramData/NCR APTRA/SLAMonitorTool/', 'notificationData.json')
function notifyData(data)
{
  var totalData='';
  var data = JSON.parse(data);
  console.log(data)
  var missedJira = data[0].Missed_Jiras
  var missJira = "";
  
  missedJira.forEach(element => {
      if (missJira) {
          missJira = missJira + ", " + element;
      }
      else
      missJira = element

    });
    var missed="MissedJiras-"+missJira
    console.log(missed)
    var actionJira = "";
    var Approaching_Jiras = data[0].Approaching_Jiras
    Approaching_Jiras.forEach(element => {
        if (actionJira) {
          actionJira = actionJira + ", " + element;
        }
        else
          actionJira = element

      });
      var approaching="ApproachingJiras-"+actionJira
      console.log(approaching)
      totalData=missed +'\n' +approaching
      return totalData;

    }


function getNotified() {
  fs.readFile(notificationpath, "utf-8", (error, data) => {
    if (error) {
      console.log(error)
      return;
    }
    try {
      //require('node-notifier');
      //const notifier = require('node-notifier');
      const WindowsBalloon = require('node-notifier').WindowsBalloon;
      var notifier = new WindowsBalloon({
        withFallback: false, // Try Windows Toast and Growl first?
        // customPath: undefined // Relative/Absolute path if you want to use your fork of notifu
      });
      const notificationData = {
        title: 'SLA Alert',
        message:'hkk',

      }
     actionJira = 'line1,line2';
     var formattedString = actionJira.split(",").join("\n")
     console.log(formattedString)
    // console.log(actionJira.split("\n"))
    //  for( var i = 0; i < actionJira.length; i++ )
       
    // if( !(str[i] == '\n' || str[i] == '\r') ) 
    //     newstr += str[i]; 
      //actionJira= actionJira.replace(/(\r)/gm,"")
   //  var actionJira= notifyData(data);//
      //var data = JSON.parse(data);

      // var actionJira = "";
      // data.forEach(element => {
      //   if (actionJira) {
      //     actionJira = actionJira + ", " + element;
      //   }
      //   else
      //     actionJira = element

      // });
      // actionJira ='AE-13639\nAE-1854'
      // console.log(actionJira)
      //console.log(path.join(__dirname, '../icons/notification.jpg'))
    //  notificationData.message = actionJira
     // console.log(notificationData.message)
  //    var lines =actionJira.split('\n');
     // console.log("lines "+ lines)
      //var formattedString = lines.split(",")
     // console.log(formattedString)

   //   console.log("lines "+lines )
// for(var i = 0;i < lines.length;i++){
//     //code here using lines[i] which will give you each line
//     console.log("lines "+lines[i].length)
// }
//       for(var i = 0;i < notificationData.message.length;i++){
//         console.log(notificationData.message[0].length)
//         //code here using lines[i] which will give you each line
//     }
   notificationData.message=formattedString;
     // var str = notificationData.message.split('\n');
      //console.log(lines)
//alert(str);
      notifier.notify({
        icon: path.join(__dirname, '../icons/notification.jpg'),
        appName: "com.SLATracker.quickstart",
        title: notificationData.title,
        message: notificationData.message,
        sound: true,
        wait: true,
        time: 20000,
        timeout: 15,
        install: "com.SLATracker.quickstart",
      },
        function (err, response) {

          // Response is response from notification
         // console.log("notificationClicked")
        });
      notifier.on('click', function (notifierObject, options, event) {
        // Triggers if `wait: true` and user clicks notification
        // Create the browser window.
        if (!win) {
          var win = new BrowserWindow({
            width: 800,
            height: 600,
            webSecurity: false,
            //icon:iconPath,
            webPreferences: {
              nodeIntegration: true
            }
          })
        }
        win.loadFile('views/notification.html')
        // currentWindow.close()
       
      });
     

    }
    catch{
      console.log("error")
    }

  })
  //
}

module.exports = getNotified;