const { app, Tray, Menu, BrowserWindow, ipcMain, Notification } = require('electron')
const path = require('path')
const fs = require('fs-extra');
const os = require('os');
const dirPath = path.join('C:/ProgramData/NCR APTRA/SLAMonitorTool/', 'input.json')
const configPath = path.join('C:/ProgramData/NCR APTRA/SLAMonitorTool/Config/', 'SLAMonitorConfig.json')
const pluginPath = path.join('C:/ProgramData/NCR APTRA/SLAMonitorTool/Plugins/', 'SLAMonitorPluginActivate.dll')
const outputFilePath = 'C:/ProgramData/NCR APTRA/SLAMonitorTool/output.json'
const notificationFilePath = 'C:/ProgramData/NCR APTRA/SLAMonitorTool/notificationData.json'
//const keytar = require('keytar')
const Notifications = require('./scripts/notifications')
var filewatcher = require('filewatcher');
const notificationpath = path.join('C:/ProgramData/NCR APTRA/SLAMonitorTool/', 'notificationData.json')

const credPath = path.join('C:/ProgramData/NCR APTRA/SLAMonitorTool/', 'cred.json')
let appIcon = null
let win = null
const iconPath = path.join(__dirname + '/icons', 'icon2.png')


// const gotTheLock = app.requestSingleInstanceLock()

// if (!gotTheLock) {
//   //console.log("found");
//   app.quit()
// } else {
//   app.on('second-instance', (event, commandLine, workingDirectory) => {
//     // Someone tried to run a second instance, we should focus our window.
//     if (win) {
//       if (win.isMinimized()) win.restore()
//       win.focus()
//     }
//   })



  app.on('ready', function () {
    app.setAppUserModelId("com.SLATracker.quickstart")
    CheckDendency();
    win = new BrowserWindow({ show: false }).setMenu(null);
    appIcon = new Tray(iconPath);

    //auto launch the app on system startup
    app.setLoginItemSettings({
      openAtLogin: true,
      path: app.getPath('exe'),
      args: [
        '--processStart', `SLAMonitorTool`,
        '--process-start-args', `"--hidden"`
      ]
    })


    var contextMenu = new Menu.buildFromTemplate([
      {

        label: 'Track Your SLA here',
        click: () => { openWindow() }
      },
      {
        label: 'Quit',
        click: () => { app.quit() }
      }
    ])
    appIcon.setToolTip("SLA Monitor Tool");
    appIcon.setContextMenu(contextMenu);

  });
//}
exports.openWindow = (fileName) => {
  let win = new BrowserWindow({
    width: 800, height: 600, icon: iconPath, webPreferences: {
      nodeIntegration: true
    }
  })
  console.log(fileName)
  win.loadFile('views/' + fileName + '.html')
  // Open the DevTools.


}


function CheckDendency() {
  const configFile = path.join(process.resourcesPath, 'extraResources', 'SLAMonitorConfig.json');
  console.log(configFile);
  const pluginFile = path.join(process.resourcesPath, 'extraResources', 'SLAMonitorPluginActivate.dll');
  console.log(pluginFile);
  const notificationFile = path.join(process.resourcesPath, 'extraResources', 'notificationData.json');
  console.log(notificationFile);
  const outputFile = path.join(process.resourcesPath, 'extraResources', 'output.json');
  console.log(outputFile)
  fs.access(configPath, fs.F_OK, (err) => {
    if (err) {
      DirectoryCopy(configFile, 'C:/ProgramData/NCR APTRA/SLAMonitorTool/Config/SLAMonitorConfig.json');
    }
  })
  fs.access(pluginPath, fs.F_OK, (err) => {
    if (err) {
      DirectoryCopy(pluginFile, 'C:/ProgramData/NCR APTRA/SLAMonitorTool/Plugins/SLAMonitorPluginActivate.dll');
    }
  })
  fs.access(outputFilePath, fs.F_OK, (err) => {
    if (err) {
      copyFile(outputFile, outputFilePath)
    }
  })
  fs.access(notificationFilePath, fs.F_OK, (err) => {
    var notify = filewatcher();
    if (err) {
      // copyFile(notificationFile,notificationFilePath)
      fs.copyFile(notificationFile, notificationFilePath, (err) => {
        if (err) throw err;

        notify.add(notificationpath)
        notify.on('change', function (notificationpath, stat) {
          console.log('File modified: %s', notificationpath);
          Notifications()
          if (!stat) console.log('deleted');
        });

      });


    }
    else {
      notify.add(notificationpath)
      notify.on('change', function (notificationpath, stat) {
        console.log('File modified: %s', notificationpath);
        Notifications()
        if (!stat) console.log('deleted');
      });

    }
  })

}

function copyFile(source, destination) {
  fs.copyFile(source, destination, (err) => {
    if (err) throw err;
    console.log('File was copied to destination');

  });

}


function DirectoryCopy(source, destination) {
  // copy source folder to destination
  fs.copy(source, destination, function (err) {
    if (err) {
      console.log('An error occured while copying the folder.')
      return console.error(err)
    }
    //  console.log('Copy completed!')
  });
}


function openWindow() {
  //CheckDendency();
  // Create the browser window.
  var win = new BrowserWindow({
    width: 800,
    height: 600,
    icon: iconPath,
    webPreferences: {
      nodeIntegration: true
    }
  })

  try {
    var username;
    var password;

    //get crendentials from window credentials-Not using 
    // const credentials= await keytar.findCredentials('SLATool')
    //  if(credentials!=null)
    //  {
    //    username =credentials[0].account;
    //    password =credentials[0].password;
    //  }

    fs.readFile(credPath, "utf-8", (error, data) => {
      if (error) {
        win.loadFile('views/index.html')
        return;
        //console.error("error: " + error);
      }
      //console.log(data)
      var data = JSON.parse(data);

      if (data.username != null && data.password != null) {
        win.loadFile('views/main.html')
      }
      else {
        win.loadFile('views/index.html')
      }

    });

  }
  catch{

    win.loadFile('views/index.html')
  }
}

exports.handleForm = function handleForm(targetWindow, Username) {
  console.log("this is the Username from the form ->", Username)
  targetWindow.webContents.send('form-received', Username);
};

// Quit when all windows are closed.
app.on('window-all-closed', () => {
  app.quit();
})

/*app.on('activate', () => {
  // On macOS it's common to re-create a window in the app when the
  // dock icon is clicked and there are no other windows open.
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow()
  }
})
*/
// In this file you can include the rest of your app's specific main process
// code. You can also put them in separate files and require them here.
